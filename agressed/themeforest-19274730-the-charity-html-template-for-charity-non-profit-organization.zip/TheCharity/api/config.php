<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'YOUR KEY HERE');
    define('CONSUMER_SECRET', 'YOUR KEY HERE');

    // User Access Token
    define('ACCESS_TOKEN', 'YOUR KEY HERE');
    define('ACCESS_SECRET', 'YOUR KEY HERE');